package soohan530.google.com.jjoji_project.DataBean

data class ExamASlot(var examNo : Int, var examNumber : Int, var examAName : String)