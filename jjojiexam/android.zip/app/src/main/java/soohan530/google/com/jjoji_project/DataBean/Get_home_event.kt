package soohan530.google.com.jjoji_project.DataBean


data class Get_home_event(var eventName : String, var eventImage : String)