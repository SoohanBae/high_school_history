package soohan530.google.com.jjoji_project.DataBean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Get_home_event_par(var eventName : String, var eventImage : String) : Parcelable{

}
