package soohan530.google.com.jjoji_project.DataBean

data class Get_home_userCount(var userName : String, var notEndCount : Int, var endCount : Int, var scoreAvg : Double, var userEmail : String)
