package soohan530.google.com.jjoji_project.DataBean

data class Get_user_list(var classCode : String, var className : String, var noExamCount: Int)