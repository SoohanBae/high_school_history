package soohan530.google.com.jjoji_project.DataBean

//class BaseUtil <T> {
//    var success : String? = null
//    var message : String? = null
//    var errors : String? = null
//    var data : T? = null
//}

data class Post_answer_A (var resultANumber : Int, var examARight : String)