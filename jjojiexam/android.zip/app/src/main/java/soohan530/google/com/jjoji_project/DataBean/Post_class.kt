package soohan530.google.com.jjoji_project.DataBean

data class Post_class(var classCode :String)