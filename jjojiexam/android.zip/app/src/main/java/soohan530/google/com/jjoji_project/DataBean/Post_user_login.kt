package soohan530.google.com.jjoji_project.DataBean

data class Post_user_login(var userEmail : String, var userPw : String)