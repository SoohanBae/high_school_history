package soohan530.google.com.jjoji_project.DataBean

data class Post_user_login_result(var userName : String, var userEmail : String, var userType : Int)

