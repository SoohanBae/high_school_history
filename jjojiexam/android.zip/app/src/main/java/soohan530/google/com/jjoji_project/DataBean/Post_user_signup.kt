package soohan530.google.com.jjoji_project.DataBean

data class Post_user_signup(var userName : String, var userEmail : String, var userPw : String, var userType:Int)